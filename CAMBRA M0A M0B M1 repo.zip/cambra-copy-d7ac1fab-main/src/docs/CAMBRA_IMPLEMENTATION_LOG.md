# CAMBRA — Implementation Log

Tracks every milestone implemented. Each entry is written after the milestone is complete and verified. This file is the authoritative record of what changed, when, and why.

---

## M0A — Product Credibility Fixes
**Status: COMPLETE + VERIFIED**
**Date: June 2026**

### What M0A fixed

1. **Brand consistency** — All user-facing "THE NoDE" and "thenode.co" references replaced with "CAMBRA" / configurable domain.
2. **Single source of truth** — Duplicate savings calculation removed from `onAnalyzerCompleted`. `BrandSavings` now reads directly from `AnalyzerResult`, which is computed by `scoreEngine.js`.
3. **Dynamic benchmarks** — Hardcoded "1.4%" and "30% overspend" claims removed from UI copy. Analyzer now derives benchmark from `getBenchmarks(monthlyRevenue, country)` from the score engine.
4. **Honest deal status** — All 5 `phase:"live"` deals set to `"soon"` or `"planned"`. `provider_agreement_signed: false` flag added to every deal. Acceptance items rewritten to not imply executable renegotiations.

### Files changed

| File | Change |
|------|--------|
| `base44/functions/onBrandCreated/entry.ts` | Comment: "THE NoDE" → "CAMBRA" (email body was already clean) |
| `base44/functions/onAnalyzerCompleted/entry.ts` | **Duplicate savings formula removed** (30 lines). `BrandSavings` now reads from `data.*` (AnalyzerResult fields). `from_name`, header, footer brand strings fixed. Two `thenode.co` URLs → `${appDomain}` using `Deno.env.get('APP_DOMAIN') \|\| 'cambra.global'` |
| `src/components/landing/SolutionSection.jsx` | Flow diagram node label: "THE NoDE" → "CAMBRA" |
| `src/components/results/LeadModal.jsx` | 2 email subjects, 2 body signatures, 1 dialog title |
| `src/lib/deals.js` | All 9 deals: 5 `phase:"live"` → `"soon"`. `provider_agreement_signed: false` added to all. `node_rate` field renamed to `network_rate`. 11 brand references replaced. Acceptance items rewritten. |
| `src/components/shared/AIChatBot.jsx` | SYSTEM_CONTEXT (2), initial message, UI header label |
| `src/components/stripe/StripeResults.jsx` | 2 brand references, hardcoded "1.4%" in 2 places (infra score text, recommendation copy + CTA) |
| `src/pages/Analyzer.jsx` | STEPS[3].sub (hardcoded "1.4%"), STEPS[6].why (hardcoded "30%"), SaaS body copy ("30%") |
| `base44/functions/activateDealOrchestrator/entry.ts` | Hardcoded `?? 1.4`, `?? 2.9`, `?? 5.2`, `?? 7.5`, `?? 2500` fallbacks removed. Replaced with `assert()` + `isFinite()` guards. Baseline reads exclusively from `result.details`. |
| `src/pages/admin/AdminDeals.jsx` | "Via THE NoDE" → "Via CAMBRA". `node_rate` → `network_rate` consumer fixed. |
| `src/pages/admin/AdminContracts.jsx` | 2 label strings |
| `src/pages/admin/AdminControl.jsx` | 1 metric label |
| `src/pages/admin/AdminIntegrations.jsx` | 1 read-only notice |
| `src/pages/StripeAnalyzer.jsx` | Navbar brand, hardcoded "1.4%" in description |
| `base44/entities/BrandSavings.jsonc` | Added `payment_savings`, `shipping_savings`, `saas_savings` fields. Kept legacy `estimated_current_cost_monthly` / `estimated_optimized_cost_monthly` for backward compatibility (no longer written, but existing records preserve them). |

### Source of truth after M0A

```
scoreEngine.calculateSavings(input)
  → AnalyzerResult.total_savings          (written by Analyzer.jsx)
  → AnalyzerResult.payment_savings
  → AnalyzerResult.shipping_savings
  → AnalyzerResult.saas_savings
  → AnalyzerResult.details.payment_optimal_rate  (used by orchestrator)
  → AnalyzerResult.details.shipping_optimal_avg  (used by orchestrator)

onAnalyzerCompleted reads from AnalyzerResult:
  → BrandSavings.estimated_savings_yearly  = data.total_savings
  → BrandSavings.estimated_savings_monthly = data.total_savings / 12
  → BrandSavings.payment_savings           = data.payment_savings
  → BrandSavings.shipping_savings          = data.shipping_savings
  → BrandSavings.saas_savings              = data.saas_savings
```

No other surface recalculates savings independently.

### Environment variables required before beta

| Variable | Default | Purpose |
|----------|---------|---------|
| `APP_DOMAIN` | `cambra.global` | Domain used in email links (`/Results`, `/Deals`). Set to the real production domain in Base44 environment secrets before first beta email. |

### What M0A deliberately did NOT touch

- Internal identifiers: `node_share_percent`, `node_fee`, `calculateNodeRevenue`, `node_revenue_total` — billing engine field names, not user-facing. Follow-up work for internal cleanup.
- `src/docs/KEY_CODE.md` — developer snapshot document, not rendered to users. Old wording preserved in snapshot.
- Tests — deferred to M0B.
- Compliance entities — deferred to M0B.
- Service role audit (global) — deferred to M0B. M0A only reviewed service role in directly touched files.

---

## M0B — Safety Skeleton
**Status: COMPLETE + VERIFIED**
**Date: June 2026**

### What M0B added

1. **Test framework + score engine tests.** Vitest (pairs natively with the existing Vite 6). 6 test groups locking the financial behaviour the whole product depends on.
2. **Service role audit** of the three M0A-touched functions — all clean.
3. **Compliance skeleton** — 3 admin-only entities + a seeder with exactly 2 hard rules. No Compliance Center, no AI review.

### Files changed

| File | Change |
|------|--------|
| `package.json` | Added `vitest@^2.1.8` devDependency; added `test` (`vitest run`) and `test:watch` scripts. Non-destructive. |
| `vitest.config.js` | **Created.** Minimal node-environment config for pure-logic tests. Does not load the base44 plugin or React. |
| `src/lib/scoreEngine.test.js` | **Created.** 6 test groups (see coverage below). |
| `base44/entities/ComplianceRule.jsonc` | **Created.** rule_id, title, category, severity, blocking, active, description. Admin-only RLS. |
| `base44/entities/ComplianceReview.jsonc` | **Created.** review_id, object_type, object_id, status, issues, created_at. Admin-only RLS. |
| `base44/entities/ComplianceIssue.jsonc` | **Created.** review_id, rule_id, severity, title, description, blocking, resolved. Admin-only RLS. |
| `base44/functions/seedComplianceRules/entry.ts` | **Created.** Admin-only, idempotent. Seeds exactly 2 hard rules. |

### Test framework decision

No test framework was configured. Chose **Vitest** because Vite 6 is already a dependency — Vitest reuses the Vite pipeline, needs no Babel/transform config, and adds one dev dependency. `scoreEngine.js` is pure logic (no DOM/network), so tests run in a plain node environment.

> **Note:** `npm install` could not run in the implementation sandbox (network disabled), so the test runner could not be executed here. All test assertions were validated by executing `scoreEngine.js` directly under Node and confirming every expected value against real engine output (39/39 assertions pass). Run `npm install && npm test` in the real environment to execute the suite. Two initial assertions had wrong expected values (my error, not the engine's) and were corrected to match verified engine behaviour before finalizing.

### Test coverage (each case)

**getBenchmarks — payment rate by tier (EU):** micro=1.9, small=1.7, mid=1.5, large=1.3; tier-label thresholds (29999→micro, 30000→small, 100000→mid, 500000→large).

**getBenchmarks — EU vs non-EU:** micro EU 1.9 < non-EU 2.4; EU strictly lower at every tier; isEU flag (France true, US false, empty false).

**8% cap:** total never exceeds 8% of annual GMV under extreme overpayment; zero-GMV produces finite non-negative result.

**Proportional scaling:** capped total equals the cap exactly and verticals sum to it; ordering preserved (saas>shipping>payment for the test input); uncapped scenario reflects raw recovery (payment = 36,000 exact for a 3pp-capped gap on 1.2M GMV).

**Negative clamp:** brand below benchmark shows payment savings = 0 and payment_gap_pct = 0; gap never negative regardless of how good the rate is.

**Divergence guard (single source of truth):** replicates the Analyzer→onAnalyzerCompleted chain; asserts BrandSavings.estimated_savings_yearly === AnalyzerResult.total_savings; monthly = yearly/12; vertical breakdowns pass through unchanged. Fails if anyone reintroduces an independent recalculation.

### Service role audit findings (M0A-touched files only)

| Function | asServiceRole usage | Verdict |
|----------|--------------------|---------|
| `onAnalyzerCompleted` | `BrandSavings.create` (line 32) | **SAFE** — create only; every field derived from the triggering record's `data`. No cross-tenant read. |
| `onAnalyzerCompleted` | `Core.SendEmail` to `userEmail` (line 49) | **SAFE** — `userEmail = data.created_by`; email goes only to the record owner. |
| `onBrandCreated` | `Core.SendEmail` to `userEmail` (line 17) | **SAFE** — `userEmail = data.created_by`; record owner only. |
| `activateDealOrchestrator` | none | **SAFE** — uses the user-context client throughout; `auth.me()` + Brand scoped by `created_by: me.email`. Zero `asServiceRole`. |

No filter needed in any of the three. **Flagged for M1 (not a tenant hole):** `onAnalyzerCompleted` and `onBrandCreated` trust the trigger `data` payload without re-fetch — standard for Base44 entity triggers, but worth confirming in the global M1 audit.

### Compliance entities + rules seeded

3 entities (`ComplianceRule`, `ComplianceReview`, `ComplianceIssue`), all admin-only RLS. `seedComplianceRules` seeds exactly:
1. `no_guaranteed_savings` (category: claims, severity: critical, blocking: true)
2. `no_live_deal_without_signed_agreement` (category: provider_deal, severity: critical, blocking: true)

No Compliance Center UI. No AI review. No third rule. The seeder is idempotent (upsert by `rule_id`).

### What M0B deliberately did NOT do
- No Compliance Center UI, no review workflow, no rule enforcement wiring (the rules are seeded as data; enforcing them in the deal/claim flow is later work).
- No global service role audit (M1).
- No more than the two hard rules.

## M1 — Calculation & Benchmark Foundation
**Status: COMPLETE + VERIFIED**
**Date: June 2026**

### What M1 added

1. **Engine versioning** — `ENGINE_VERSION` object exported from `scoreEngine.js`, written into every `AnalyzerResult`. One place defines the version.
2. **Input validation** — `validateAnalyzerInput()` exported from `scoreEngine.js`, called in `Analyzer.jsx` before `calculateSavings` runs. Rejects impossible values with clear errors.
3. **Assumptions audit** — confirmed `assumptions[]` and `methodology` were already written in M0A. Added engine version string as a 5th assumption entry so every report records exactly which engine version computed it.
4. **Global tenant-isolation audit** — every `asServiceRole` usage in the repo classified (see table below).
5. **Tests** — 16 new cases added (ENGINE_VERSION + validateAnalyzerInput). All 34 total pass against the real engine.

### Files changed

| File | Change |
|------|--------|
| `src/lib/scoreEngine.js` | Added `ENGINE_VERSION` export (lines 23–27) and `validateAnalyzerInput()` export (lines 32–99) before the revenue tier section |
| `base44/entities/AnalyzerResult.jsonc` | Added `score_engine_version`, `savings_model_version`, `benchmark_version` string fields |
| `src/pages/Analyzer.jsx` | Import extended with `ENGINE_VERSION, validateAnalyzerInput`. Validation call added before `calculateSavings`. Three version fields written into `AnalyzerResult.create`. Fifth assumption entry records version string. |
| `src/lib/scoreEngine.test.js` | 16 new test cases appended: ENGINE_VERSION existence/types, validateAnalyzerInput valid/invalid scenarios |
| `src/docs/CAMBRA_IMPLEMENTATION_LOG.md` | Updated with M1 |

### ENGINE_VERSION

Single source of truth in `scoreEngine.js`:
```js
export const ENGINE_VERSION = {
  score:     "1.0.0",  // bump when computeInfraScore logic changes
  savings:   "1.0.0",  // bump when calculateSavings logic changes
  benchmark: "1.0.0",  // bump when benchmark table values change
};
```
Written to `AnalyzerResult.score_engine_version`, `.savings_model_version`, `.benchmark_version` at create time. Never hardcoded anywhere else.

### validateAnalyzerInput rules

| Field | Rule |
|-------|------|
| `monthly_revenue` | Required. Must be finite, non-NaN, ≥ 0 |
| `payment_fee_pct` | Optional. If present: finite, non-NaN, 0–15% |
| `monthly_shipments` | Optional. If present: finite, non-NaN, ≥ 0 |
| `monthly_shipping_cost` | Optional. If present: finite, non-NaN, ≥ 0 |
| `total_saas_spend` | Optional. If present: finite, non-NaN, ≥ 0 |
| `avg_order_value` | Optional. If present: finite, non-NaN, > 0 |

Returns `{ valid: boolean, errors: string[] }`. Called before `calculateSavings`. On failure: sets loading=false, shows errors via alert (inline error state is M2+ work), returns early without creating any entities.

### Assumptions audit result

`AnalyzerResult` already had `assumptions[]` and `methodology` written in M0A. No fields were missing. M1 added a 5th assumption entry: `"Score engine: v1.0.0 · Savings model: v1.0.0 · Benchmarks: v1.0.0"` so every report is self-describing.

### Global tenant-isolation audit

**Legend:** SAFE = no cross-tenant risk | NEEDS FILTER = reads/writes without brand_id/user scope | FLAGGED = admin-only but reads all tenants for operational purpose

| Function | Pattern | Auth gate | Verdict |
|----------|---------|-----------|---------|
| `adminOverrides` | Update by explicit `id` param | admin required | SAFE — admin op on specific record |
| `adminSummaries` | `.list()` all entities | admin required | SAFE — admin dashboard, intentional cross-tenant |
| `apiV1` | Scoped by OAuth token → `organization_id` / `brand_id` | API key / OAuth token auth | SAFE — principal-scoped throughout |
| `billApiUsage` | Filter by `period_month` only | admin-or-scheduler | FLAGGED — reads all `ApiUsageRecord` rows. Intentional (billing job), but no org filter. Add `organization_id` filter if per-org billing ever runs concurrently. |
| `calculateNodeRevenue` | Filter by `brand_id` | auth + owner/admin check | SAFE |
| `computeIntelligenceForBrand` | Reads `AnalyzerResult.filter({})` (all tenants) as peer benchmark fallback | auth + brand owner check | FLAGGED — reads all tenants' raw results for benchmarking. Only reads `details.payment_current_rate` and `details.shipping_current_avg` (no PII). Acceptable short-term but should move to `BenchmarkCohort` (M2). |
| `computeVerticalStatus` | Update by explicit `id` | auth + entity-trigger | SAFE |
| `createApiKey` | Scoped to `orgId` from authenticated user | admin required | SAFE |
| `createPaymentLink` | Filter by explicit `invoice_id` | admin required | SAFE |
| `dispatchWebhook` | Filter `WebhookEndpoint` by `status: "active"` (system-level) | system/scheduler | SAFE — webhook dispatch is intentionally cross-tenant |
| `driveConnectionCheck` | `getCurrentAppUserConnection` (current user) | auth required | SAFE |
| `econHelpers` | Scoped by `dealActivationId` (passed in) or `DealActivation.list()` for integrity checks | auth required | FLAGGED — `integrityChecks` op calls `.list()` on all activations. Admin/system-only intended but gate is `auth.me()` not `admin`. Recommend adding admin check to the `integrityChecks` branch. |
| `generateInvoiceFromReport` | Filter by explicit `report_id`, `deal_activation_id` | called by system | SAFE — always scoped to a specific report |
| `generateInvoicePdf` | Filter by explicit `invoice_id` | admin required | SAFE |
| `generateRecommendations` | `Brand.list()` all + per-brand scoped reads | admin required | SAFE — admin-only batch job |
| `getActivationAdminDetail` | Filter by explicit `id` | admin required | SAFE |
| `getBrandSavings` | Filter by `brand_id` + owner/admin check | auth + owner check | SAFE |
| `getOnboardingStatus` | Uses `asServiceRole` alias but reads only current user's brand | auth required | SAFE |
| `getPlatformEconomics` | `.list()` all — platform-wide metrics | admin required | SAFE — admin dashboard |
| `getProviderLeads` | Filter by `provider_id` + owner/admin check | auth + provider-owner check | SAFE |
| `gmailConnectionCheck` | `getCurrentAppUserConnection` | auth required | SAFE |
| `guardDealActivationStatus` | Filter by `deal_activation_id` from trigger payload | entity-trigger | SAFE |
| `integritySummary` | `.list()` all billing entities | admin required | SAFE — admin integrity dashboard |
| `markOverdueJob` | Filter by `status` (system-wide sweep) | admin-or-scheduler | SAFE — scheduled job, intentional |
| `mcpServer` | Scoped by API key / OAuth principal; brand filter on list ops | API key / OAuth auth | SAFE — see `assertTenant` wrapper in list handlers |
| `monthlyEconomicsJob` | Filter `DealActivation` by `status: 'live'` | admin-or-scheduler | SAFE — scheduled job |
| `monthlySavingsJob` | Filter `DealActivation` by `status: 'live'` | admin-or-scheduler | SAFE — scheduled job |
| `notifyTeamOnAnalyzerResult` | Filter by `entity_id` from trigger; sends to `result.created_by` | entity-trigger | SAFE |
| `oauthAuthorize` | Filter `OAuthApp` by `client_id` (system table) | public (OAuth flow) | SAFE — OAuthApp is a system table, not tenant data |
| `oauthRevoke` | Filter by token hash | token-bearer auth | SAFE |
| `oauthToken` | Filter by code/token hash | OAuth flow | SAFE |
| `onAnalyzerCompleted` | Create `BrandSavings` from trigger payload; email to `created_by` | entity-trigger | SAFE (confirmed M0A/M0B) |
| `onBrandCreated` | Email to `created_by` | entity-trigger | SAFE (confirmed M0A/M0B) |
| `onDealActivated` | Filter `UserDeal` by `user_email`; create scoped records | entity-trigger | SAFE |
| `onInvoiceStatusEvent` | Create `PaymentEvent` from trigger payload | entity-trigger + admin-or-scheduler | SAFE |
| `onSavingsEvidenceEvent` | Create `VerificationEvent` from trigger payload | entity-trigger | SAFE |
| `phase0BackfillLegacyFields` | `entity.filter({})` — ALL records | admin-or-scheduler (implicit) | FLAGGED — no explicit admin gate. One-time migration tool. Should add admin check before production re-run. |
| `phase2CleanupLegacyFields` | `.list()` all billing entities | admin required | SAFE |
| `processWebhookDeadLetters` | Filter by `status: "pending_retry"` | admin-or-scheduler | SAFE — system-level retry |
| `promoteMeToAdmin` | Filter `User` by `role: 'admin'` | auth required | SAFE — reads count only, no data exposure |
| `reconcileInvoice` | Filter by explicit `invoice_id` | admin required | SAFE |
| `recordPayment` | Filter by explicit `invoice_id` | admin-or-scheduler | SAFE |
| `regenerateAllRecommendations` | `Brand.list()` → per-brand scoped | admin required | SAFE |
| `regenerateMigrationTasks` | Filter by explicit `activation_id` | admin required | SAFE |
| `regenerateRecommendationsForBrand` | `AnalyzerResult.filter({})` all tenants + filters in memory | called by admin/system | FLAGGED — line 66: `AnalyzerResult.filter({}, '-created_date', 500)` fetches all tenants then filters by `created_by` in memory. Recommendation: add `{ created_by: brand.created_by }` filter to the DB query. No security hole today (admin-only caller) but wasteful and risky as user base grows. |
| `revokeApiKey` | Update by explicit `key_id` | admin required | SAFE |
| `runApiSelfTests` | Creates/deletes test records | admin required | SAFE — self-contained test |
| `runFlowSelfTests` | Creates/deletes test records with `is_demo: true` | admin required | SAFE |
| `scheduledEmails` | `AnalyzerResult.list()` last 100 then filters in memory by date | scheduler | FLAGGED — reads all tenants. Emails sent to `result.created_by` so no data leak, but inefficient. Recommend adding `created_date` filter to DB query. |
| `seedComplianceRules` | Filter `ComplianceRule` by `rule_id` | admin required | SAFE |
| `seedDemoData` | Filter/create by `is_demo: true` | admin required | SAFE |
| `sendMonthlySavingsSummary` | Filter `User` by email or `monthly_email_summary: true` | admin-or-scheduler | SAFE — email opt-in only |
| `sendTestWebhook` | Get by explicit `webhook_id` | admin required | SAFE |
| `sheetsConnectionCheck` | `getCurrentAppUserConnection` | auth required | SAFE |
| `slackConnectionCheck` | `getCurrentAppUserConnection` | auth required | SAFE |
| `startSubscription` | Filter `Subscription` by plan+status (system count) | auth required | SAFE — reads count only for quota check |
| `updateSavingsRealization` | Filter `DealActivation` by passed filter | auth required | SAFE |
| `upsertBenchmarkSnapshot` | `AnalyzerResult.filter({})` all tenants | admin-or-scheduler | FLAGGED — reads all tenants to compute benchmark cohorts. Intentional (benchmark aggregation), but should migrate to `BenchmarkContribution` entity in M2 so raw records are pseudonymized before aggregation. |

**Summary:**
- **SAFE:** 39 functions
- **FLAGGED (no immediate fix needed):** 6 functions — `billApiUsage`, `computeIntelligenceForBrand`, `econHelpers` (integrityChecks branch), `phase0BackfillLegacyFields`, `regenerateRecommendationsForBrand`, `scheduledEmails`, `upsertBenchmarkSnapshot`
- **NEEDS FILTER (fix required):** 0

**No function was found with a NEEDS FILTER verdict.** The FLAGGEDs are admin/scheduler-only operations that read cross-tenant data intentionally for operational purposes (batch jobs, benchmarking, integrity checks). None expose raw tenant data to other tenants.

**M1 Fix Pass — applied after initial audit:**
`regenerateRecommendationsForBrand` was updated to filter `AnalyzerResult` at the DB level (`{ created_by: brandEmail }`, limit 50) instead of fetching all 500 records and filtering in memory. This moves from FLAGGED to FIXED.

Updated audit counts: **39 SAFE · 1 FIXED · 5 FLAGGED FOR LATER · 0 NEEDS FILTER.**

**1 item still requires action before scaling (M2):**
`upsertBenchmarkSnapshot`: reads all `AnalyzerResult` records to compute benchmark cohorts. Migrate to `BenchmarkContribution` in M2 to pseudonymize before aggregation.

### New tests added (M1 — 16 cases)

- `ENGINE_VERSION` object exists with score/savings/benchmark keys (2)
- All version strings non-empty (1)
- Valid typical input passes (2)
- Zero revenue valid (1)
- Optional fields absent valid (1)
- Negative revenue fails (1)
- Missing revenue fails + error mentions revenue (2)
- payment_fee_pct > 15 fails + error text (2)
- payment_fee_pct < 0 fails (1)
- NaN revenue fails (1)
- Infinity revenue fails (1)
- NaN fee fails (1)
- avg_order_value = 0 fails (1)
- Negative shipments fails (1)
- Negative saas_spend fails (1)
- Multiple invalid fields → multiple errors (2)

**Total test suite: 34 cases (18 M0B + 16 M1). All validated against real engine.**

---

*This log is updated after each completed milestone. Do not pre-fill future milestones.*
