import { defineConfig } from 'vitest/config';

// Minimal Vitest config for pure-logic unit tests (M0B).
// Deliberately does NOT load the base44 vite plugin or React — scoreEngine.js is
// framework-free pure logic, so tests run in a plain node environment with no DOM.
// This keeps the test runner isolated and fast, and avoids coupling tests to the
// app's build pipeline.
export default defineConfig({
  test: {
    environment: 'node',
    include: ['src/**/*.test.{js,jsx,ts,tsx}'],
    globals: true,
  },
});
