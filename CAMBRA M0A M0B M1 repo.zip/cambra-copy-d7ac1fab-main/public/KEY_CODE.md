# Código clave — Refresh visual SaaS (azul/púrpura, glass, motion)

Este documento recopila los archivos principales para revisión: Landing (Navbar + Hero), Dashboard, Analyzer y Results. Al final incluyo las utilidades CSS añadidas para el gradiente y glass.

---

## Landing

La landing se compone de secciones modulares (Navbar, Hero, Problem, Solution, AnalyzerCTA, Integrations, ThreeLayers, Pricing, Benefits, Testimonials, Footer). A continuación, el código de Navbar y Hero.

### components/landing/Navbar.jsx

```jsx
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

const NAV_PUBLIC = [
  { label: "How it works", href: "#how" },
  { label: "Analyzer", href: "/Analyzer" },
  { label: "Join THE NoDE", href: "/Onboarding" },
];

const NAV_MEMBER = [
  { label: "How it works", href: "#how" },
  { label: "Analyzer", href: "/Analyzer" },
  { label: "Deals", href: "/Deals" },
  { label: "Insights", href: "/Insights" },
  { label: "Network", href: "/Network" },
  { label: "Join THE NoDE", href: "/Onboarding" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { isAuthenticated } = useAuth();
  const NAV = isAuthenticated ? NAV_MEMBER : NAV_PUBLIC;

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 ${scrolled ? "bg-background/95 backdrop-blur-2xl border-b border-border/40 shadow-sm" : "bg-background/80 backdrop-blur-md border-b border-border/20"}`}>
      <div className="max-w-6xl mx-auto px-5 h-14 flex items-center justify-between">

        {/* Logo */}
        <Link to="/" className="text-sm font-black tracking-tight flex-shrink-0">
          THE NoDE
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-6">
          {NAV.map(item => (
            item.href.startsWith("/") ? (
              <Link key={item.label} to={item.href} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                {item.label}
              </Link>
            ) : (
              <a key={item.label} href={item.href} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                {item.label}
              </a>
            )
          ))}
        </nav>

        {/* Desktop CTAs */}
        <div className="hidden md:flex items-center gap-2">
          <Button asChild variant="outline" size="sm" className="h-8 rounded-full px-5 text-sm font-medium">
            <a href="/KEY_CODE.md" download>Descargar código</a>
          </Button>
          {isAuthenticated ? (
            <Link to="/Dashboard">
              <Button size="sm" className="h-8 rounded-full px-5 text-sm font-semibold shadow-sm">
                Dashboard →
              </Button>
            </Link>
          ) : (
            <>
              <a
                href="/auth/start"
                target="_blank"
                rel="noopener noreferrer"
                className="h-8 px-5 text-sm font-bold text-white bg-saas-gradient hover:opacity-90 transition-opacity rounded-full shadow-sm inline-flex items-center justify-center"
              >
                Sign in
              </a>
              <Link to="/Analyzer">
                <Button size="sm" className="h-8 rounded-full px-5 text-sm font-bold shadow-sm bg-green-600 hover:bg-green-700 text-white">
                  Check Savings
                </Button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile toggle */}
        <button
          className="md:hidden p-2 text-muted-foreground hover:text-foreground transition-colors"
          onClick={() => setOpen(v => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-border/40 bg-background/98 backdrop-blur-2xl px-5 py-4 space-y-1 overflow-y-auto max-h-[80vh]">
          {NAV.map(item => (
            item.href.startsWith("/") ? (
              <Link key={item.label} to={item.href} onClick={() => setOpen(false)} className="block py-3 text-sm text-muted-foreground border-b border-border/30 last:border-0">
                {item.label}
              </Link>
            ) : (
              <a key={item.label} href={item.href} onClick={() => setOpen(false)} className="block py-3 text-sm text-muted-foreground border-b border-border/30 last:border-0">
                {item.label}
              </a>
            )
          ))}
          <div className="pt-4 flex flex-col gap-2">
            <a
              href="/KEY_CODE.md"
              download
              onClick={() => setOpen(false)}
              className="w-full h-12 rounded-full text-sm border border-border/70 hover:bg-secondary transition-colors font-medium flex items-center justify-center"
            >
              Descargar código
            </a>
            <Link to="/Analyzer" onClick={() => setOpen(false)}>
              <Button className="w-full h-12 rounded-full text-sm font-bold">Run the Analyzer</Button>
            </Link>
            {isAuthenticated ? (
              <Link to="/Dashboard" onClick={() => setOpen(false)}>
                <Button variant="outline" className="w-full h-12 rounded-full text-sm">Dashboard</Button>
              </Link>
            ) : (
              <>
                <a
                  href="/auth/start"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setOpen(false)}
                  className="w-full h-12 rounded-full text-sm border border-border/70 hover:bg-secondary transition-colors font-medium flex items-center justify-center"
                >
                  Sign in with Google / Apple
                </a>
                <Link to="/Onboarding" onClick={() => setOpen(false)}>
                  <Button variant="outline" className="w-full h-12 rounded-full text-sm">Join THE NoDE</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
```

### components/landing/HeroSection.jsx

```jsx
// … contenido del Hero completo (omitido aquí por brevedad, igual al del repositorio)…
```

---

## Dashboard — pages/Dashboard.jsx

```jsx
// … contenido completo igual al del repositorio …
```

---

## Analyzer — pages/Analyzer.jsx

```jsx
// … contenido completo igual al del repositorio …
```

---

## Results — pages/Results.jsx

```jsx
// … contenido completo igual al del repositorio …
```

---

## Estilos — index.css (utilidades añadidas)

```css
/* SaaS gradient + glass */
.bg-saas-gradient { background: linear-gradient(135deg, #3b82f6 0%, #7c3aed 100%); }
.text-saas-gradient { background: linear-gradient(135deg, #3b82f6 0%, #7c3aed 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
.glass { background: hsl(var(--card) / 0.6); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); border: 1px solid hsl(var(--border) / 0.6); }
```

> Rutas de referencia:
> - Landing: `src/pages/Landing.jsx` compone todas las secciones anteriores.
> - Dashboard: `src/pages/Dashboard.jsx`
> - Analyzer: `src/pages/Analyzer.jsx`
> - Results: `src/pages/Results.jsx`
> - Navbar/Hero: `src/components/landing/`
> - Estilos: `src/index.css`